# WinPCMode 3.0

This project is an Android desktop shell designed to provide a Windows-style PC experience.

## Important
It is **not Microsoft Windows itself**. Android remains the underlying operating system.
A true Windows installation/boot environment requires compatible hardware, firmware, drivers,
and a real Windows build or virtualization/emulation solution.

## Included
- Windows-style desktop and wallpaper
- Start menu and app search
- Taskbar with running-app buttons
- Clock/date system tray
- Desktop icons
- Draggable application windows
- Minimize / maximize / close
- Browser
- File view
- Notepad with persistence
- Calculator
- Terminal using Android's shell
- Settings and About

## Build
Open this folder in Android Studio and let Gradle sync. Then build:
Build > Build Bundle(s) / APK(s) > Build APK(s)

For a physical Android device, landscape orientation is enforced.

## Limitation
The shell cannot turn Android into Microsoft's proprietary Windows OS. It provides a
Windows-like desktop layer on top of Android.
